To add an icon to this application:

1. Create an .icns file named "AppIcon.icns"
2. Place it in this directory (AITerminal.app/Contents/Resources/)

You can create an .icns file using tools like:
- Icon Composer (part of Xcode)
- Image2icon (https://apps.apple.com/us/app/image2icon-make-your-own-icons/id992115977)
- iconutil command line tool

For a quick solution, you can also use a terminal icon from the SF Symbols app and convert it to .icns format. 